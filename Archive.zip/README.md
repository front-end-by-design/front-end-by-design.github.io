# Introduction
This site contains a summary of the projects currently stored in GitHub.  Its purpose is to highlight the implementation of various technologies, features and learning.

This is a private repository and while it can be viewed by anyone, it should only be updated by the owner.

# Overview
This "site" is comprised of three basic fleas:

* index.html
* stylesheet.css
* javascript.js

Knowledge

+ HTML5
+ CSS3
+ JavaScript (ECMAScript 5.1/6)
+ jQuery (v3.3.1)
+ Bootstrap (v3/4)
+ Sass (v3.5.6)
+ Node.js (v9.6.1)
+ nvm (v0.33.8)
+ npm (v6.0.1)

`code`

```
Several lines 
of code go here
surrounded by ```
```
1. `F1`

`cmd`+ `shift` + `p`

`ctrl`+ `shift` + `p`

`
though it is broken up
this is displayed
as a single line
`

